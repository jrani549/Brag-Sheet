# BragSheet — AI Career Page Builder
### Replit Agent 4 Buildathon Submission

> Turn your resume into a full personal career page in seconds — with skill graphs, project showcase, LinkedIn-style contact card, and an AI chatbot that answers recruiters *as you*.

---

## What it does

Paste or upload your resume → BragSheet uses Claude AI to instantly generate:

- **Hero section** — name, role, professional summary
- **Animated skill bars** — proficiency graph for top skills
- **Tech tag cloud** — all your tools and technologies
- **Experience timeline** — roles, companies, achievements
- **Project showcase** — cards with tech tags
- **Certifications** — visual list
- **LinkedIn-style contact card** — with social links (LinkedIn, GitHub, Email, Portfolio)
- **AI recruiter chatbot** — answers questions in your voice
- **Export options** — download HTML, copy embed snippet, deploy on Replit

---

## Project structure

```
bragsheet/
├── public/
│   └── index.html      # Full frontend (single-file app)
├── server.js           # Express backend + Anthropic API routes
├── package.json
├── .replit             # Replit deployment config
└── README.md
```

---

## Deploy on Replit (step by step)

### 1. Create a new Replit project
- Go to [replit.com](https://replit.com) → **Create Repl**
- Choose **Node.js** template
- Name it `bragsheet`

### 2. Upload the files
Upload these files into your Repl:
- `public/index.html`
- `server.js`
- `package.json`
- `.replit`
- `README.md`

Or import directly from GitHub if you push this repo there.

### 3. Add your Anthropic API key
- In Replit, open the **Secrets** tab (lock icon in left sidebar)
- Add a new secret:
  - **Key:** `ANTHROPIC_API_KEY`
  - **Value:** your Anthropic API key from [console.anthropic.com](https://console.anthropic.com)

### 4. Install dependencies
In the Replit Shell:
```bash
npm install
```

### 5. Run
Click the **Run** button — your app starts on port 3000.
Replit will give you a public URL like:
```
https://bragsheet.yourname.repl.co
```

### 6. Deploy (for permanent URL)
- Click **Deploy** in the top bar
- Choose **Autoscale** or **Reserved VM**
- Your live URL is your Buildathon submission link!

---

## Local development

```bash
# Install dependencies
npm install

# Set your API key
export ANTHROPIC_API_KEY=your_key_here

# Run the server
npm start
# → http://localhost:3000
```

---

## API routes

| Method | Route | Description |
|--------|-------|-------------|
| `POST` | `/api/generate` | Parse resume → return structured profile JSON |
| `POST` | `/api/chat` | Recruiter chatbot — answers as the candidate |

### `/api/generate` request body
```json
{ "resume": "Paste full resume text here..." }
```

### `/api/chat` request body
```json
{
  "messages": [ { "role": "user", "content": "What is your GenAI experience?" } ],
  "system": "You are Janshi Rani. Answer as her, concisely."
}
```

---

## Tech stack

| Layer | Tech |
|-------|------|
| Frontend | Vanilla HTML/CSS/JS (zero dependencies) |
| Backend | Node.js + Express |
| AI | Anthropic Claude claude-sonnet-4-20250514 |
| Hosting | Replit |

---

## Buildathon category

**Portfolio / Personal Branding** — BragSheet is a direct response to Replit's own "Brag Sheet" demo, built as a full product anyone can use to generate their career page from a resume in under 30 seconds.

---

## Built by

**Janshi Rani** — Applied Data Scientist & GenAI Engineer, Bengaluru
IIT Hyderabad · ex-Amazon Development Centre
[LinkedIn](#) · [GitHub](#)
